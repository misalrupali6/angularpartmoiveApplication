import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ReactiveFormsModule, FormBuilder, FormGroup, Validators } from '@angular/forms';
import { MovieService, Movie } from '../movies/movie.service';

@Component({
  selector: 'app-admin-movies',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule],
  templateUrl: './admin-movies.component.html',
  styleUrls: ['./admin-movies.component.scss']
})

export class AdminMoviesComponent implements OnInit {
  movies: Movie[] = [];
  movieForm: FormGroup;
  isEditMode: boolean = false;
  successMessage: string = '';
  errorMessage: string = '';
  selectedMovieId: number | null = null;

  constructor(
    private movieService: MovieService,
    private fb: FormBuilder
  ) {
    this.movieForm = this.fb.group({
      title: ['', Validators.required],
      genre: ['', Validators.required],
      language: ['', Validators.required],
      posterUrl: ['', Validators.required],
      duration: [0, [Validators.required, Validators.min(1)]]
    });
  }

  ngOnInit(): void {
    this.fetchMovies();
  }

  fetchMovies(): void {
    this.movieService.getAllMovies().subscribe({
      next: (data) => {
        this.movies = data;
      },
      error: (err) => {
        this.errorMessage = 'Failed to fetch movies';
        console.error(err);
      }
    });
  }

  onSubmit(): void {
    const movieData = this.movieForm.value;
    if (this.isEditMode && this.selectedMovieId !== null) {
      this.movieService.updateMovie(this.selectedMovieId, movieData).subscribe({
        next: () => {
          this.successMessage = 'Movie updated successfully';
          this.resetForm();
          this.fetchMovies();
        },
        error: () => this.errorMessage = 'Failed to update movie'
      });
    } else {
      this.movieService.addMovie(movieData).subscribe({
        next: () => {
          this.successMessage = 'Movie added successfully';
          this.resetForm();
          this.fetchMovies();
        },
        error: () => this.errorMessage = 'Failed to add movie'
      });
    }
  }

  editMovie(movie: Movie): void {
    this.movieForm.patchValue({
      title: movie.title,
      genre: movie.genre,
      language: movie.language,
      posterUrl: movie.posterUrl,
      duration: movie.duration
    });
    this.selectedMovieId = movie.id;
    this.isEditMode = true;
  }

  deleteMovie(id: number): void {
    const confirmDelete = confirm('Are you sure you want to delete this movie?');
    if (!confirmDelete) return;

    this.successMessage = '';
    this.errorMessage = '';

    this.movieService.deleteMovie(id).subscribe({
      next: () => {
        this.successMessage = '✅ Movie deleted successfully!';
        this.fetchMovies();
      },
      error: (err) => {
        console.error('Delete failed', err);
        this.errorMessage = '❌ Failed to delete the movie. Please try again.';
      }
    });
  }

  resetForm(): void {
    this.movieForm.reset();
    this.isEditMode = false;
    this.selectedMovieId = null;
    this.successMessage = '';
    this.errorMessage = '';
  }
}
