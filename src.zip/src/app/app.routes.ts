import { Routes } from '@angular/router';

export const routes: Routes = [
    { path: '', redirectTo: 'login', pathMatch: 'full' },
    {
        path: 'login',
        loadComponent: () => import('./auth/login/login.component').then(m => m.LoginComponent)
    },
    {
        path: 'register',
        loadComponent: () => import('./auth/register/register.component').then(m => m.RegisterComponent)
    },
    {
        path: 'home',
        loadComponent: () => import('./Home/home.component').then(m => m.HomeComponent)
    },
    {
        path: 'movies',
        loadComponent: () => import('./movies/movie-list.component').then(m => m.MovieListComponent)
    },
    {
        path: 'admin/movies',
        loadComponent: () => import('./admin/admin-movies.component').then(m => m.AdminMoviesComponent)
    },
    {
        path: 'booking/:id',
        loadComponent: () => import('./booking/booking.component').then(m => m.BookingComponent)
    }
];
