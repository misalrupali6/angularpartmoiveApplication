import { ComponentFixture, TestBed } from '@angular/core/testing';
import { BookingComponent } from './booking/booking.component'; // ✅ Right path
import { ReactiveFormsModule } from '@angular/forms';

describe('BookingComponent', () => {
  let component: BookingComponent;
  let fixture: ComponentFixture<BookingComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      // ✅ Remove declarations, use imports instead
      imports: [BookingComponent, ReactiveFormsModule]
    }).compileComponents();

    fixture = TestBed.createComponent(BookingComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create the component', () => {
    expect(component).toBeTruthy();
  });

  // Add your additional tests here...
});
