import { Component } from '@angular/core';
import { FormBuilder, Validators, ReactiveFormsModule } from '@angular/forms';
import { Router } from '@angular/router';
import { AuthService } from '../../core/auth.service';

import { CommonModule } from '@angular/common';
import { MatCardModule } from '@angular/material/card';
import { MatInputModule } from '@angular/material/input';
import { MatButtonModule } from '@angular/material/button';

@Component({
  selector: 'app-login',
  standalone: true,
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.scss'],
  imports: [
    CommonModule,
    ReactiveFormsModule,
    MatCardModule,
    MatInputModule,
    MatButtonModule
  ]
})
export class LoginComponent {
  loading = false; // ✅ This line fixes the error

  constructor(private fb: FormBuilder, private auth: AuthService, private router: Router) { }

  loginForm = this.fb.group({
    email: ['', [Validators.required, Validators.email]],
    password: ['', Validators.required]
  });

  onSubmit() {
    if (this.loginForm.valid) {
      this.loading = true;

      const loginData = this.loginForm.getRawValue() as { email: string; password: string };
      this.auth.login(loginData).subscribe({
        next: () => {
          alert('Login successful!');
          this.router.navigate(['/home']);
        },
        error: (err: any) => {
          alert('Login failed: ' + (err.error?.message || 'Invalid credentials'));
        },
        complete: () => {
          this.loading = false;
        }
      });
    }
  }
}
