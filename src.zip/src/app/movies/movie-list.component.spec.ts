import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-movie-list',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './movie-list.component.html',
  styleUrls: ['./movie-list.component.scss']
})
export class MovieListComponent {
  movies = [
    {
      id: 1,
      title: 'Avengers',
      genre: 'Action',
      duration: 140,
      imageUrl: 'assets/images/avengers.jpg'
    },
    {
      id: 2,
      title: 'Inception',
      genre: 'Sci-Fi',
      duration: 148,
      imageUrl: 'assets/images/inception.jpg'
    },
    {
      id: 3,
      title: 'Joker',
      genre: 'Drama',
      duration: 122,
      imageUrl: 'assets/images/joker.jpeg'
    }
  ];
}
