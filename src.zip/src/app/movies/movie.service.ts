import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

export interface Movie {
    id: number;
    title: string;
    genre: string;
    language: string;
    duration: number;
    posterUrl: string;
}

@Injectable({
    providedIn: 'root'
})
export class MovieService {
    private apiUrl = 'https://localhost:44353/api/Movies'; // Your backend API

    constructor(private http: HttpClient) { }

    getAllMovies(): Observable<Movie[]> {
        return this.http.get<Movie[]>(this.apiUrl);
    }

    getMovieById(id: number): Observable<Movie> {
        return this.http.get<Movie>(`${this.apiUrl}/${id}`);
    }

    addMovie(movie: Omit<Movie, 'id'>): Observable<Movie> {
        return this.http.post<Movie>(this.apiUrl, movie);
    }

    updateMovie(id: number, movie: Omit<Movie, 'id'>): Observable<void> {
        return this.http.put<void>(`${this.apiUrl}/${id}`, movie);
    }

    deleteMovie(id: number): Observable<void> {
        return this.http.delete<void>(`${this.apiUrl}/${id}`);
    }
}
