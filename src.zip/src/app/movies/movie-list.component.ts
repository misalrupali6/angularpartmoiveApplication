import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-movie-list',
  standalone: true,
  imports: [CommonModule], // ✅ This line is essential for *ngFor and *ngIf
  templateUrl: './movie-list.component.html',
  styleUrls: ['./movie-list.component.scss']
})
export class MovieListComponent {
  movies = [
    {
      id: 1,
      title: 'Avengers',
      genre: 'Action',
      duration: 140,
      description: 'A thief who steals corporate secrets through dream-sharing technology.',
      imageUrl: 'assets/images/avengers.jpg'
    },
    {
      id: 2,
      title: 'Inception',
      genre: 'Sci-Fi',
      duration: 148,
      description: 'A thief who steals corporate secrets through dream-sharing technology.',
      imageUrl: 'assets/images/inception.jpg'
    },
    {
      id: 3,
      title: 'Joker',
      genre: 'Drama',
      duration: 122,
      description: 'A thief who steals corporate secrets through dream-sharing technology.',
      imageUrl: 'assets/images/joker.jpeg'
    },
    {
      id: 4,
      title: 'Roses',
      genre: 'Romance',
      duration: 120,
      description: 'A romantic drama about love and loss.',
      imageUrl: 'assets/images/roses.jpeg'
    }
  ];
}
