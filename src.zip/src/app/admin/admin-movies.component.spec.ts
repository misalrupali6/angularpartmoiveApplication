import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { HttpClient } from '@angular/common/http';
import { CommonModule } from '@angular/common';
import { ReactiveFormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';

@Component({
    selector: 'app-admin-movies',
    standalone: true,
    imports: [CommonModule, ReactiveFormsModule, HttpClientModule],
    templateUrl: './admin-movies.component.html',
    styleUrls: ['./admin-movies.component.scss']
})
export class AdminMoviesComponent implements OnInit {
    movieForm: FormGroup;
    movies: any[] = [];
    isEditMode = false;
    selectedMovieId: number | null = null;
    successMessage = '';
    errorMessage = '';

    genres = ['Action', 'Comedy', 'Drama', 'Horror', 'Sci-Fi'];
    languages = ['English', 'Hindi', 'Spanish', 'French', 'German'];

    constructor(private fb: FormBuilder, private http: HttpClient) {
        this.movieForm = this.fb.group({
            title: ['', Validators.required],
            genre: ['', Validators.required],
            language: ['', Validators.required],
            duration: ['', [Validators.required, Validators.min(30)]],
            posterUrl: ['', Validators.required]
        });
    }

    ngOnInit(): void {
        this.loadMovies();
    }

    get title() {
        return this.movieForm.get('title');
    }

    loadMovies(): void {
        this.http.get<any[]>('/api/movies').subscribe({
            next: data => this.movies = data,
            error: () => this.errorMessage = 'Failed to load movies'
        });
    }

    onSubmit(): void {
        if (this.movieForm.invalid) return;

        const movieData = this.movieForm.value;

        if (this.isEditMode && this.selectedMovieId !== null) {
            // 🔁 EDIT
            this.http.put(`/api/movies/${this.selectedMovieId}`, movieData).subscribe({
                next: () => {
                    this.successMessage = 'Movie updated successfully!';
                    this.resetForm();
                    this.loadMovies();
                },
                error: () => this.errorMessage = 'Update failed.'
            });
        } else {
            // ➕ ADD
            this.http.post('/api/movies', movieData).subscribe({
                next: () => {
                    this.successMessage = 'Movie added successfully!';
                    this.resetForm();
                    this.loadMovies();
                },
                error: () => this.errorMessage = 'Add failed.'
            });
        }
    }

    editMovie(movie: any): void {
        this.isEditMode = true;
        this.selectedMovieId = movie.id;
        this.movieForm.patchValue(movie);
    }

    deleteMovie(id: number): void {
        if (confirm('Are you sure you want to delete this movie?')) {
            this.http.delete(`/api/movies/${id}`).subscribe({
                next: () => {
                    this.successMessage = 'Movie deleted successfully!';
                    this.loadMovies();
                },
                error: () => this.errorMessage = 'Delete failed.'
            });
        }
    }

    resetForm(): void {
        this.movieForm.reset();
        this.isEditMode = false;
        this.selectedMovieId = null;
    }

    clearForm(): void {
        this.movieForm.reset({
            title: '',
            genre: '',
            language: '',
            duration: 0,
            posterUrl: ''
        });
        this.isEditMode = false;
        this.selectedMovieId = null;
    }
}
