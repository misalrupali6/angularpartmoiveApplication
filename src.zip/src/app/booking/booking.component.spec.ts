import { ComponentFixture, TestBed } from '@angular/core/testing';
import { BookingComponent } from './booking.component';
import { ReactiveFormsModule } from '@angular/forms';

describe('BookingComponent', () => {
  let component: BookingComponent;
  let fixture: ComponentFixture<BookingComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [
        BookingComponent,         // ✅ standalone component goes in `imports`
        ReactiveFormsModule       // ✅ if you're using Reactive Forms
      ]
    }).compileComponents();

    fixture = TestBed.createComponent(BookingComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create the component', () => {
    expect(component).toBeTruthy();
  });

  it('should initialize the form with 3 controls', () => {
    const form = component.bookingForm;
    expect(form.contains('movie')).toBeTrue();
    expect(form.contains('seats')).toBeTrue();
    expect(form.contains('date')).toBeTrue();
  });

  it('should mark form as invalid when empty', () => {
    component.bookingForm.setValue({ movie: '', seats: '', date: '' });
    expect(component.bookingForm.invalid).toBeTrue();
  });

  it('should mark form as valid with correct input', () => {
    component.bookingForm.setValue({ movie: 'Inception', seats: '2', date: '2025-07-20' });
    expect(component.bookingForm.valid).toBeTrue();
  });
});
