import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { HttpClientModule, HTTP_INTERCEPTORS } from '@angular/common/http';
import { ReactiveFormsModule } from '@angular/forms';
import { RouterModule } from '@angular/router';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations'; // ✅ ADD THIS

import { AppComponent } from './app.component'; // ✅ Standalone
import { AuthInterceptor } from './interceptors/auth.interceptor';
import { routes } from './app.routes';

@NgModule({
    imports: [
        BrowserModule,
        BrowserAnimationsModule, // ✅ Required for Angular Material animations
        HttpClientModule,
        ReactiveFormsModule,
        RouterModule.forRoot(routes),
        AppComponent
    ],
    providers: [
        {
            provide: HTTP_INTERCEPTORS,
            useClass: AuthInterceptor,
            multi: true
        }
    ]
})
export class AppModule { }
